# GANTTI — Cronograma de proyectos (PWA, sin backend)

App tipo Gantt para gestión de proyectos y tareas: proyectos, prioridades por color,
dependencias visibles, alarmas, subtareas, y vistas Panel / Gantt / Lista / Calendario.
100% en el navegador, sin servidor. Instalable y funciona sin conexión (PWA).

## Archivos para EJECUTAR / DESPLEGAR (app de producción)
Sube TODOS estos al mismo directorio de un hosting estático:

- `index.html` ............. punto de entrada (app completa, autónoma)
- `manifest.webmanifest` ... metadatos PWA (nombre, íconos, instalación)
- `sw.js` .................. service worker (caché offline)
- `icon-192.png` .......... ícono
- `icon-512.png` .......... ícono
- `icon-512-maskable.png` . ícono adaptable (Android)
- `GANTTI.html` ........... copia portable de un solo archivo (abre con doble clic, sin instalar)

## Archivos FUENTE (para editar / recompilar — no son necesarios para ejecutar)
- `Gantt Marketing.dc.html` . código fuente del componente
- `support.js` ............... runtime del framework

## Cómo publicarlo (gratis, sin backend)
1. Sube la carpeta a Netlify Drop (https://app.netlify.com/drop), GitHub Pages o Cloudflare Pages.
2. Entra por la URL HTTPS que te den.
3. En el navegador/móvil usa "Instalar app". Ya funciona offline.

Nota: el modo PWA (instalación + offline) requiere servir por HTTPS.
Para uso local rápido sin publicar, abre `GANTTI.html` directamente.

## Datos
Se guardan solo en el navegador (localStorage). Usa "Exportar" para respaldar a un
archivo `.json` e "Importar" para restaurarlo en otro dispositivo o navegador.
